//
//  AdgeistCreatives.h
//  AdgeistCreatives
//
//  Created by kishore on 16/04/25.
//

#import <Foundation/Foundation.h>

//! Project version number for AdgeistCreatives.
FOUNDATION_EXPORT double AdgeistCreativesVersionNumber;

//! Project version string for AdgeistCreatives.
FOUNDATION_EXPORT const unsigned char AdgeistCreativesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdgeistCreatives/PublicHeader.h>


